package charts;

public class ChartVals {
	private int[] chartVals;

	public ChartVals(int[] chartVals) {
		this.chartVals = chartVals;
	}

	public int[] getChartVals() {
		return chartVals;
	}

	public void setChartVals(int[] chartVals) {
		this.chartVals = chartVals;
	}
	
	
}
