[SMFAjax23SP]

1. 스프링을 이용한 비동기통신 테스트
2. 제이쿼리
3. Ajax
4. JSON

(JSON Library)
https://code.google.com/archive/p/json-simple/downloads
json-simple-1.1.1.jar -> Tomcat:/lib


(실행)
http://localhost:8584/SMFAjax23SP/chartx1